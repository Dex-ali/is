package modelbd;


/**
 *
 * @author Ferz
 */
public interface IModel {
    
    
}
